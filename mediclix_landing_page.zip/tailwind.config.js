module.exports = {
	theme: {
		screens: {
			sm: "640px",
			md: "768px",
			lg: "1033px",
			xl: "1280px",
			"2xl": "1536px",
		},
	},
};
